import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

public class NumberGuessingGame extends JFrame {

    // ── Game state ──────────────────────────────────────────────────────────
    private int secretNumber;
    private int attempts;
    private int low = 1, high = 100;
    private boolean gameWon = false;
    private ArrayList<int[]> guessHistory = new ArrayList<>(); // {value, type: 0=low,1=high,2=win}

    // ── UI Components ────────────────────────────────────────────────────────
    private AnimatedTextField guessField;
    private PulseButton guessButton;
    private GlassButton newGameButton;
    private JLabel feedbackLabel, attemptsLabel, rangeLabel, subtitleLabel;
    private JPanel historyPanel;
    private AnimatedProgressBar progressBar;
    private GlassPanel mainCard;
    private ParticlePanel particleLayer;

    // ── Design Tokens ────────────────────────────────────────────────────────
    static final Color BG1          = new Color(10,  12,  30);
    static final Color BG2          = new Color(18,  20,  48);
    static final Color GLASS_BG     = new Color(255, 255, 255, 18);
    static final Color GLASS_BORDER = new Color(255, 255, 255, 40);
    static final Color ACCENT1      = new Color(130,  90, 255);
    static final Color ACCENT2      = new Color(200,  80, 255);
    static final Color ACCENT_GLOW  = new Color(130,  90, 255, 80);
    static final Color TEXT_PRI     = new Color(240, 240, 255);
    static final Color TEXT_SEC     = new Color(160, 160, 200);
    static final Color LOW_BG       = new Color(255, 180,  40, 60);
    static final Color LOW_RIM      = new Color(255, 190,  60);
    static final Color LOW_FG       = new Color(255, 210, 100);
    static final Color HIGH_BG      = new Color(255,  70,  90, 60);
    static final Color HIGH_RIM     = new Color(255,  80, 100);
    static final Color HIGH_FG      = new Color(255, 130, 140);
    static final Color WIN_BG       = new Color( 80, 220, 140, 60);
    static final Color WIN_RIM      = new Color(100, 230, 160);
    static final Color WIN_FG       = new Color(150, 255, 190);

    // ── Animation state ───────────────────────────────────────────────────────
    private float shakeX = 0;
    private Timer shakeTimer;
    private int shakeStep = 0;
    private float feedbackAlpha = 0f;
    private Timer fadeTimer;

    public NumberGuessingGame() {
        setTitle("Number Guessing Game");
        setSize(480, 660);
        setMinimumSize(new Dimension(420, 580));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setUndecorated(false);
        setBackground(BG1);

        // Custom title bar via look-and-feel
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}

        startNewGame();
        buildUI();
        setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI CONSTRUCTION
    // ════════════════════════════════════════════════════════════════════════

    private void buildUI() {
        // Root – gradient background + particle layer
        GradientPanel root = new GradientPanel();
        root.setLayout(new BorderLayout());

        particleLayer = new ParticlePanel();
        particleLayer.setLayout(new GridBagLayout());

        mainCard = new GlassPanel(20);
        mainCard.setLayout(new BoxLayout(mainCard, BoxLayout.Y_AXIS));
        mainCard.setBorder(BorderFactory.createEmptyBorder(28, 30, 28, 30));
        mainCard.setPreferredSize(new Dimension(400, 560));
        mainCard.setMaximumSize(new Dimension(400, 560));

        buildCardContents();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        particleLayer.add(mainCard, gbc);

        root.add(particleLayer);
        add(root);
    }

    private void buildCardContents() {
        mainCard.removeAll();

        // ── Title section ────────────────────────────────────────────────
        JPanel headerRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        headerRow.setOpaque(false);

        // Icon
        JLabel iconLbl = new JLabel("🎯");
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 32));
        iconLbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 8));
        headerRow.add(iconLbl);

        JPanel titleStack = new JPanel();
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        titleStack.setOpaque(false);

        GradientLabel titleLabel = new GradientLabel("Number Quest");
        titleLabel.setFont(loadFont(26, Font.BOLD));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        subtitleLabel = new JLabel("Guess the number between 1 and 100");
        subtitleLabel.setFont(loadFont(13, Font.PLAIN));
        subtitleLabel.setForeground(TEXT_SEC);
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        titleStack.add(titleLabel);
        titleStack.add(Box.createVerticalStrut(3));
        titleStack.add(subtitleLabel);
        headerRow.add(titleStack);
        headerRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        mainCard.add(headerRow);
        mainCard.add(Box.createVerticalStrut(22));

        // ── Stats row ────────────────────────────────────────────────────
        JPanel statsRow = new JPanel(new GridLayout(1, 2, 12, 0));
        statsRow.setOpaque(false);
        statsRow.setAlignmentX(Component.CENTER_ALIGNMENT);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));

        attemptsLabel = makeStatNum("0");
        rangeLabel    = makeStatNum("1 – 100");

        statsRow.add(makeStatCard("Attempts", attemptsLabel, "🔢"));
        statsRow.add(makeStatCard("Range",    rangeLabel,    "📏"));

        mainCard.add(statsRow);
        mainCard.add(Box.createVerticalStrut(16));

        // ── Progress bar ─────────────────────────────────────────────────
        JLabel progressLbl = new JLabel("Attempts Used");
        progressLbl.setFont(loadFont(11, Font.PLAIN));
        progressLbl.setForeground(TEXT_SEC);
        progressLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainCard.add(progressLbl);
        mainCard.add(Box.createVerticalStrut(5));

        progressBar = new AnimatedProgressBar();
        progressBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        progressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 10));
        mainCard.add(progressBar);
        mainCard.add(Box.createVerticalStrut(18));

        // ── Input row ────────────────────────────────────────────────────
        JPanel inputRow = new JPanel(new BorderLayout(10, 0));
        inputRow.setOpaque(false);
        inputRow.setAlignmentX(Component.CENTER_ALIGNMENT);
        inputRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));

        guessField = new AnimatedTextField();
        guessField.setFont(loadFont(20, Font.BOLD));
        guessField.addActionListener(e -> handleGuess());

        guessButton = new PulseButton("Guess →");
        guessButton.setFont(loadFont(14, Font.BOLD));
        guessButton.setPreferredSize(new Dimension(110, 52));
        guessButton.addActionListener(e -> handleGuess());

        inputRow.add(guessField, BorderLayout.CENTER);
        inputRow.add(guessButton, BorderLayout.EAST);
        mainCard.add(inputRow);
        mainCard.add(Box.createVerticalStrut(14));

        // ── Feedback label ───────────────────────────────────────────────
        feedbackLabel = new JLabel("Enter a number and press Guess", SwingConstants.CENTER);
        feedbackLabel.setFont(loadFont(13, Font.PLAIN));
        feedbackLabel.setForeground(TEXT_SEC);
        feedbackLabel.setOpaque(false);
        feedbackLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        feedbackLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        feedbackLabel.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        FeedbackPanel feedbackPanel = new FeedbackPanel(feedbackLabel);
        feedbackPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        feedbackPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        mainCard.add(feedbackPanel);
        mainCard.add(Box.createVerticalStrut(14));

        // ── History ──────────────────────────────────────────────────────
        JLabel histTitle = new JLabel("Guess History");
        histTitle.setFont(loadFont(11, Font.BOLD));
        histTitle.setForeground(TEXT_SEC);
        histTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainCard.add(histTitle);
        mainCard.add(Box.createVerticalStrut(6));

        historyPanel = new JPanel(new WrapLayout(FlowLayout.LEFT, 5, 5));
        historyPanel.setOpaque(false);
        historyPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JScrollPane histScroll = new JScrollPane(historyPanel);
        histScroll.setOpaque(false);
        histScroll.getViewport().setOpaque(false);
        histScroll.setBorder(BorderFactory.createEmptyBorder());
        histScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        histScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        histScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        histScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        histScroll.setPreferredSize(new Dimension(0, 72));
        mainCard.add(histScroll);
        mainCard.add(Box.createVerticalStrut(14));

        // Re-populate chips on rebuild
        rebuildChips();

        // ── New Game button ───────────────────────────────────────────────
        newGameButton = new GlassButton("⟳  New Game");
        newGameButton.setFont(loadFont(13, Font.BOLD));
        newGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        newGameButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        newGameButton.addActionListener(e -> resetGame());
        mainCard.add(newGameButton);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  GAME LOGIC
    // ════════════════════════════════════════════════════════════════════════

    private void startNewGame() {
        secretNumber = new Random().nextInt(100) + 1;
        attempts = 0;
        low = 1;
        high = 100;
        gameWon = false;
        guessHistory.clear();
    }

    private void handleGuess() {
        if (gameWon) return;
        String text = guessField.getText().trim();
        int guess;
        try {
            guess = Integer.parseInt(text);
        } catch (NumberFormatException ex) {
            shakeField("Please enter a valid number!");
            return;
        }
        if (guess < 1 || guess > 100) {
            shakeField("Number must be between 1 and 100!");
            return;
        }

        attempts++;
        attemptsLabel.setText(String.valueOf(attempts));
        progressBar.animateTo(Math.min(attempts, 10), 10);

        if (guess == secretNumber) {
            gameWon = true;
            guessHistory.add(new int[]{guess, 2});
            setFeedback("🎉  You nailed it!  The number was " + secretNumber + "!", WIN_BG, WIN_RIM, WIN_FG);
            subtitleLabel.setText("Solved in " + attempts + (attempts == 1 ? " attempt!" : " attempts!"));
            subtitleLabel.setForeground(WIN_FG);
            guessButton.setEnabled(false);
            progressBar.setWinColor();
            particleLayer.burst(WIN_FG, 80);
        } else if (guess < secretNumber) {
            low = Math.max(low, guess + 1);
            setFeedback("⬆  Too Low!  Try a higher number.", LOW_BG, LOW_RIM, LOW_FG);
            rangeLabel.setText(low + " – " + high);
            guessHistory.add(new int[]{guess, 0});
        } else {
            high = Math.min(high, guess - 1);
            setFeedback("⬇  Too High!  Try a lower number.", HIGH_BG, HIGH_RIM, HIGH_FG);
            rangeLabel.setText(low + " – " + high);
            guessHistory.add(new int[]{guess, 1});
        }

        rebuildChips();
        guessField.setText("");
        guessField.requestFocus();
    }

    private void setFeedback(String msg, Color bg, Color rim, Color fg) {
        feedbackLabel.setText(msg);
        feedbackLabel.setForeground(fg);
        // Store colors on parent FeedbackPanel
        Container parent = feedbackLabel.getParent();
        if (parent instanceof FeedbackPanel fp) {
            fp.setColors(bg, rim);
            fp.repaint();
        }
        startFadeIn();
    }

    private void shakeField(String msg) {
        feedbackLabel.setText(msg);
        feedbackLabel.setForeground(HIGH_FG);
        Container parent = feedbackLabel.getParent();
        if (parent instanceof FeedbackPanel fp) {
            fp.setColors(HIGH_BG, HIGH_RIM);
            fp.repaint();
        }
        startFadeIn();

        if (shakeTimer != null && shakeTimer.isRunning()) shakeTimer.stop();
        shakeStep = 0;
        float[] offsets = {-8, 8, -6, 6, -4, 4, -2, 2, 0};
        shakeTimer = new Timer(30, null);
        shakeTimer.addActionListener(e -> {
            if (shakeStep < offsets.length) {
                shakeX = offsets[shakeStep++];
            } else {
                shakeX = 0;
                shakeTimer.stop();
            }
            guessField.setLocation((int)(guessField.getX() + shakeX), guessField.getY());
            guessField.repaint();
        });
        shakeTimer.start();
    }

    private void startFadeIn() {
        feedbackAlpha = 0f;
        if (fadeTimer != null && fadeTimer.isRunning()) fadeTimer.stop();
        fadeTimer = new Timer(16, null);
        fadeTimer.addActionListener(e -> {
            feedbackAlpha = Math.min(1f, feedbackAlpha + 0.08f);
            Container parent = feedbackLabel.getParent();
            if (parent instanceof FeedbackPanel fp) fp.setAlpha(feedbackAlpha);
            if (feedbackAlpha >= 1f) fadeTimer.stop();
        });
        fadeTimer.start();
    }

    private void rebuildChips() {
        if (historyPanel == null) return;
        historyPanel.removeAll();
        for (int[] entry : guessHistory) {
            Color bg, rim, fg;
            if (entry[1] == 2) { bg = WIN_BG; rim = WIN_RIM; fg = WIN_FG; }
            else if (entry[1] == 0) { bg = LOW_BG; rim = LOW_RIM; fg = LOW_FG; }
            else { bg = HIGH_BG; rim = HIGH_RIM; fg = HIGH_FG; }
            historyPanel.add(makeChip(entry[0], bg, rim, fg));
        }
        historyPanel.revalidate();
        historyPanel.repaint();
    }

    private JLabel makeChip(int value, Color bg, Color rim, Color fg) {
        String icon = "";
        JLabel chip = new JLabel(icon + value) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(rim);
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        chip.setFont(loadFont(12, Font.BOLD));
        chip.setForeground(fg);
        chip.setOpaque(false);
        chip.setBorder(BorderFactory.createEmptyBorder(4, 11, 4, 11));
        return chip;
    }

    private void resetGame() {
        startNewGame();
        attemptsLabel.setText("0");
        rangeLabel.setText("1 – 100");
        progressBar.animateTo(0, 10);
        progressBar.resetColor();
        guessButton.setEnabled(true);
        subtitleLabel.setText("Guess the number between 1 and 100");
        subtitleLabel.setForeground(TEXT_SEC);
        feedbackLabel.setText("Enter a number and press Guess");
        feedbackLabel.setForeground(TEXT_SEC);
        Container parent = feedbackLabel.getParent();
        if (parent instanceof FeedbackPanel fp) {
            fp.setColors(GLASS_BG, GLASS_BORDER);
            fp.setAlpha(1f);
            fp.repaint();
        }
        rebuildChips();
        guessField.setText("");
        guessField.requestFocus();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private Font loadFont(int size, int style) {
        return new Font("Segoe UI", style, size);
    }

    private JPanel makeStatCard(String label, JLabel valueLabel, String icon) {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Glass fill
                g2.setColor(GLASS_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                // Rim
                g2.setColor(GLASS_BORDER);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 16, 16);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        JLabel iconLbl = new JLabel(icon + "  " + label);
        iconLbl.setFont(loadFont(11, Font.PLAIN));
        iconLbl.setForeground(TEXT_SEC);
        iconLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(iconLbl);
        card.add(Box.createVerticalStrut(4));
        card.add(valueLabel);
        return card;
    }

    private JLabel makeStatNum(String text) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(loadFont(22, Font.BOLD));
        lbl.setForeground(TEXT_PRI);
        return lbl;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(NumberGuessingGame::new);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CUSTOM COMPONENTS
    // ════════════════════════════════════════════════════════════════════════

    // ── Gradient background panel ─────────────────────────────────────────
    static class GradientPanel extends JPanel {
        GradientPanel() { setOpaque(true); setLayout(new BorderLayout()); }
        @Override protected void paintComponent(Graphics g) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            GradientPaint gp = new GradientPaint(0, 0, BG1, w, h, BG2);
            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);
            // Subtle radial glow in the middle — guard radius > 0
            float radius = Math.max(w, h) * 0.6f;
            if (radius > 0) {
                RadialGradientPaint rg = new RadialGradientPaint(
                    new Point2D.Float(w / 2f, h / 2f),
                    radius,
                    new float[]{0f, 1f},
                    new Color[]{new Color(130, 90, 255, 30), new Color(0, 0, 0, 0)}
                );
                g2.setPaint(rg);
                g2.fillRect(0, 0, w, h);
            }
            g2.dispose();
        }
    }

    // ── Glassmorphism card ────────────────────────────────────────────────
    static class GlassPanel extends JPanel {
        private final int radius;
        GlassPanel(int radius) {
            this.radius = radius;
            setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) { super.paintComponent(g); return; }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            // Blurred glass fill
            g2.setColor(new Color(255, 255, 255, 14));
            g2.fillRoundRect(0, 0, w, h, radius * 2, radius * 2);
            // Top highlight — guard against zero height
            int h3 = Math.max(1, h / 3);
            GradientPaint top = new GradientPaint(0, 0, new Color(255, 255, 255, 35),
                0, h3, new Color(255, 255, 255, 0));
            g2.setPaint(top);
            g2.fillRoundRect(0, 0, w, h3, radius * 2, radius * 2);
            // Border
            g2.setColor(GLASS_BORDER);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(0, 0, w - 1, h - 1, radius * 2, radius * 2);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ── Gradient title label ───────────────────────────────────────────────
    static class GradientLabel extends JLabel {
        GradientLabel(String text) { super(text); setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setFont(getFont());
            GradientPaint gp = new GradientPaint(0, 0, ACCENT1, getWidth(), 0, ACCENT2);
            g2.setPaint(gp);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), 0, fm.getAscent());
            g2.dispose();
        }
        @Override public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(getText()) + 4, fm.getHeight() + 4);
        }
    }

    // ── Animated text field ───────────────────────────────────────────────
    static class AnimatedTextField extends JTextField {
        private float focusAlpha = 0f;
        private Timer focusTimer;

        AnimatedTextField() {
            setOpaque(false);
            setForeground(TEXT_PRI);
            setCaretColor(ACCENT2);
            setFont(new Font("Segoe UI", Font.BOLD, 20));
            setHorizontalAlignment(SwingConstants.CENTER);
            setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

            addFocusListener(new FocusAdapter() {
                public void focusGained(FocusEvent e) { animateFocus(true); }
                public void focusLost(FocusEvent e)   { animateFocus(false); }
            });
        }
        private void animateFocus(boolean gaining) {
            if (focusTimer != null) focusTimer.stop();
            focusTimer = new Timer(16, null);
            focusTimer.addActionListener(ev -> {
                focusAlpha = gaining ? Math.min(1f, focusAlpha + 0.1f)
                                     : Math.max(0f, focusAlpha - 0.1f);
                repaint();
                if (gaining && focusAlpha >= 1f) focusTimer.stop();
                if (!gaining && focusAlpha <= 0f) focusTimer.stop();
            });
            focusTimer.start();
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            // Base glass fill
            g2.setColor(new Color(255, 255, 255, 22));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            // Border
            g2.setColor(new Color(255, 255, 255, 50));
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 14, 14);
            // Focus glow
            if (focusAlpha > 0) {
                Color glowC = new Color(ACCENT1.getRed(), ACCENT1.getGreen(), ACCENT1.getBlue(), (int)(80 * focusAlpha));
                g2.setColor(glowC);
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawRoundRect(1, 1, getWidth()-3, getHeight()-3, 12, 12);
            }
            g2.dispose();
            super.paintComponent(g);
        }
        @Override public boolean isOpaque() { return false; }
        @Override protected void paintBorder(Graphics g) {}
    }

    // ── Pulsating primary button ───────────────────────────────────────────
    static class PulseButton extends JButton {
        private float hoverScale = 1f;
        private float pulseAlpha = 0f;
        private Timer hoverTimer, pulseTimer;

        PulseButton(String text) {
            super(text);
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { animateHover(true); }
                public void mouseExited(MouseEvent e)  { animateHover(false); }
                public void mousePressed(MouseEvent e) { startPulse(); }
            });
        }
        private void animateHover(boolean in) {
            if (hoverTimer != null) hoverTimer.stop();
            hoverTimer = new Timer(16, null);
            hoverTimer.addActionListener(e -> {
                hoverScale = in ? Math.min(1.04f, hoverScale + 0.006f)
                                : Math.max(1.00f, hoverScale - 0.006f);
                repaint();
                if (in && hoverScale >= 1.04f) hoverTimer.stop();
                if (!in && hoverScale <= 1.00f) hoverTimer.stop();
            });
            hoverTimer.start();
        }
        private void startPulse() {
            pulseAlpha = 0.6f;
            if (pulseTimer != null) pulseTimer.stop();
            pulseTimer = new Timer(20, null);
            pulseTimer.addActionListener(e -> {
                pulseAlpha = Math.max(0f, pulseAlpha - 0.05f);
                repaint();
                if (pulseAlpha <= 0f) pulseTimer.stop();
            });
            pulseTimer.start();
        }
        @Override protected void paintComponent(Graphics g) {
            if (!isEnabled()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(100, 100, 120, 80));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.setColor(new Color(130, 130, 160, 120));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
                return;
            }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int cx = getWidth() / 2, cy = getHeight() / 2;
            g2.translate(cx, cy);
            g2.scale(hoverScale, hoverScale);
            g2.translate(-cx, -cy);

            // Glow — clamp alpha to valid 0-255 range
            float glowStrength = Math.max(0f, hoverScale - 1f) / 0.04f; // 0..1
            for (int i = 0; i < 3; i++) {
                int pad = (i + 1) * 3;
                int a = Math.max(0, Math.min(255, (int)((30 - i * 8) * glowStrength)));
                if (a == 0) continue;
                Color gc = new Color(ACCENT1.getRed(), ACCENT1.getGreen(), ACCENT1.getBlue(), a);
                g2.setColor(gc);
                g2.fillRoundRect(-pad, -pad, getWidth() + pad*2, getHeight() + pad*2, 18, 18);
            }

            // Gradient fill
            GradientPaint gp = new GradientPaint(0, 0, ACCENT1, getWidth(), getHeight(), ACCENT2);
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);

            // Pulse ripple
            if (pulseAlpha > 0) {
                g2.setColor(new Color(255, 255, 255, (int)(pulseAlpha * 120)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            }

            // Top sheen — guard zero height
            int halfH = Math.max(1, getHeight() / 2);
            GradientPaint sheen = new GradientPaint(0, 0, new Color(255, 255, 255, 60),
                0, halfH, new Color(255, 255, 255, 0));
            g2.setPaint(sheen);
            g2.fillRoundRect(2, 2, getWidth()-4, halfH, 12, 12);

            // Text
            g2.setColor(Color.WHITE);
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int tx = (getWidth() - fm.stringWidth(getText())) / 2;
            int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(getText(), tx, ty);
            g2.dispose();
        }
    }

    // ── Glass secondary button ────────────────────────────────────────────
    static class GlassButton extends JButton {
        private float hover = 0f;
        private Timer hoverTimer;
        GlassButton(String text) {
            super(text);
            setOpaque(false); setContentAreaFilled(false);
            setBorderPainted(false); setFocusPainted(false);
            setForeground(TEXT_SEC);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { animate(true); }
                public void mouseExited(MouseEvent e)  { animate(false); }
            });
        }
        private void animate(boolean in) {
            if (hoverTimer != null) hoverTimer.stop();
            hoverTimer = new Timer(16, null);
            hoverTimer.addActionListener(e -> {
                hover = in ? Math.min(1f, hover + 0.1f) : Math.max(0f, hover - 0.1f);
                repaint();
                if (in && hover >= 1f) hoverTimer.stop();
                if (!in && hover <= 0f) hoverTimer.stop();
            });
            hoverTimer.start();
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int alpha = (int)(20 + 30 * hover);
            g2.setColor(new Color(255, 255, 255, alpha));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.setColor(new Color(255, 255, 255, (int)(50 + 60 * hover)));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 12, 12);
            g2.setColor(hover > 0.5f ? TEXT_PRI : TEXT_SEC);
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int tx = (getWidth() - fm.stringWidth(getText())) / 2;
            int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(getText(), tx, ty);
            g2.dispose();
        }
    }

    // ── Feedback panel ────────────────────────────────────────────────────
    static class FeedbackPanel extends JPanel {
        private Color bg = GLASS_BG, rim = GLASS_BORDER;
        private float alpha = 1f;
        FeedbackPanel(JLabel child) {
            setLayout(new BorderLayout());
            setOpaque(false);
            add(child, BorderLayout.CENTER);
        }
        void setColors(Color b, Color r) { bg = b; rim = r; }
        void setAlpha(float a) { alpha = a; }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.setColor(rim);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ── Animated progress bar ──────────────────────────────────────────────
    static class AnimatedProgressBar extends JComponent {
        private float value = 0, target = 0, max = 10;
        private Color barColor = ACCENT1;
        private Timer animTimer;

        AnimatedProgressBar() { setPreferredSize(new Dimension(0, 10)); }

        void animateTo(float v, float m) {
            target = v; max = m;
            if (animTimer != null) animTimer.stop();
            animTimer = new Timer(16, null);
            animTimer.addActionListener(e -> {
                value += (target - value) * 0.12f;
                repaint();
                if (Math.abs(value - target) < 0.01f) { value = target; animTimer.stop(); }
            });
            animTimer.start();
        }
        void setWinColor()  { barColor = WIN_RIM;   repaint(); }
        void resetColor()   { barColor = ACCENT1;   repaint(); }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int h = getHeight(), w = getWidth();
            // Track
            g2.setColor(new Color(255, 255, 255, 20));
            g2.fillRoundRect(0, 0, w, h, h, h);
            // Fill
            int fillW = (int)(w * (value / max));
            if (fillW > 0) {
                GradientPaint gp = new GradientPaint(0, 0, barColor, fillW, 0,
                    barColor == WIN_RIM ? WIN_FG : ACCENT2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, fillW, h, h, h);
                // Sheen
                g2.setColor(new Color(255, 255, 255, 40));
                g2.fillRoundRect(0, 0, fillW, h / 2, h, h);
            }
            g2.dispose();
        }
    }

    // ── Floating particle background ───────────────────────────────────────
    static class ParticlePanel extends JPanel {
        private final java.util.List<Particle> particles = new ArrayList<>();
        private final Random rng = new Random();
        private Timer tickTimer;

        ParticlePanel() {
            setOpaque(false);
            for (int i = 0; i < 60; i++) spawnParticle(true);
            tickTimer = new Timer(30, e -> {
                for (Particle p : particles) p.tick();
                repaint();
            });
            tickTimer.start();
        }

        private void spawnParticle(boolean anywhere) {
            Particle p = new Particle();
            p.x = rng.nextFloat() * 480;
            p.y = anywhere ? rng.nextFloat() * 660 : 660 + rng.nextFloat() * 40;
            p.vx = (rng.nextFloat() - 0.5f) * 0.5f;
            p.vy = -(rng.nextFloat() * 0.4f + 0.1f);
            p.size = rng.nextFloat() * 3f + 1f;
            p.alpha = rng.nextFloat() * 0.5f + 0.1f;
            p.maxAlpha = p.alpha;
            p.color = rng.nextBoolean() ? ACCENT1 : ACCENT2;
            particles.add(p);
        }

        void burst(Color c, int count) {
            int cx = getWidth() / 2, cy = getHeight() / 2;
            for (int i = 0; i < count; i++) {
                Particle p = new Particle();
                p.x = cx + (rng.nextFloat() - 0.5f) * 100;
                p.y = cy + (rng.nextFloat() - 0.5f) * 80;
                double angle = rng.nextDouble() * Math.PI * 2;
                float speed = rng.nextFloat() * 3f + 1f;
                p.vx = (float)(Math.cos(angle) * speed);
                p.vy = (float)(Math.sin(angle) * speed) - 2f;
                p.size = rng.nextFloat() * 6f + 2f;
                p.alpha = 1f; p.maxAlpha = 1f;
                p.decay = 0.015f;
                p.color = c;
                particles.add(p);
            }
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            java.util.Iterator<Particle> it = particles.iterator();
            while (it.hasNext()) {
                Particle p = it.next();
                if (p.alpha <= 0) { it.remove(); spawnParticle(false); continue; }
                g2.setColor(new Color(p.color.getRed(), p.color.getGreen(), p.color.getBlue(),
                                      (int)(p.alpha * 255)));
                int s = (int) p.size;
                g2.fillOval((int)p.x - s/2, (int)p.y - s/2, s, s);
            }
            g2.dispose();
        }

        static class Particle {
            float x, y, vx, vy, size, alpha, maxAlpha, decay = 0.003f;
            Color color;
            void tick() {
                x += vx; y += vy;
                vy -= 0.005f; // slight upward drift for background particles
                alpha -= decay;
                if (alpha < 0) alpha = 0;
            }
        }
    }

    // ── WrapLayout (wraps chips properly) ─────────────────────────────────
    static class WrapLayout extends FlowLayout {
        WrapLayout(int align, int hgap, int vgap) { super(align, hgap, vgap); }
        @Override public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }
        @Override public Dimension minimumLayoutSize(Container target) {
            return layoutSize(target, false);
        }
        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int targetW = target.getSize().width;
                if (targetW == 0) targetW = Integer.MAX_VALUE;
                int hgap = getHgap(), vgap = getVgap();
                Insets insets = target.getInsets();
                int maxW = targetW - insets.left - insets.right;
                int h = 0, rowW = 0, rowH = 0;
                for (Component c : target.getComponents()) {
                    if (!c.isVisible()) continue;
                    Dimension d = preferred ? c.getPreferredSize() : c.getMinimumSize();
                    if (rowW + d.width + hgap > maxW && rowW > 0) {
                        h += rowH + vgap; rowW = 0; rowH = 0;
                    }
                    rowW += d.width + hgap;
                    rowH = Math.max(rowH, d.height);
                }
                h += rowH;
                h += insets.top + insets.bottom + vgap * 2;
                return new Dimension(targetW, h);
            }
        }
    }
}